﻿// Utilities/CoroutineRunner.cs
using System;
using System.Collections;
using BepInEx.Unity.IL2CPP.Utils.Collections; // WrapToIl2Cpp()
using Il2CppInterop.Runtime.Injection;
using UnityEngine;

namespace VeinWares.SubtleByte.Utilities
{
    public class CoroutineRunner : MonoBehaviour { }
}

This client mod provides the ability to display progress bars, action buttons and notification messages in the client UI.

Please note that this mod DOES NOT enable any gameplay modifications. This is just a client UI that will be driven by a backend mod (such as XPRising).

### Installation

- Install [BepInEx](https://thunderstore.io/c/v-rising/p/BepInEx/BepInExPack_V_Rising/).
- Install [XPShared](https://thunderstore.io/c/v-rising/p/XPRising/XPShared/).
- Extract `XPRising.ClientUI.dll` into `(VRising folder)/BepInEx/plugins`.
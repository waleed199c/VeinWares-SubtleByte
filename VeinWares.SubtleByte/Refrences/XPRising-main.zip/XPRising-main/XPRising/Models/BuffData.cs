﻿namespace XPRising.Models;

public struct BuffData
{
    public string source;
    public int targetStat;
    public int modificationType;
    public double value;
    public int ID;
    public bool isApplied;

}
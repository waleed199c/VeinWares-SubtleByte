The primary purpose of this mod is to enable server mods (such as XPRising) to communicate to XPRising.ClientUI and vice versa.

### Installation

- Install [BepInEx](https://thunderstore.io/c/v-rising/p/BepInEx/BepInExPack_V_Rising/).
- Extract `XPRising.XPShared.dll` into `(VRising folder)/BepInEx/plugins`.
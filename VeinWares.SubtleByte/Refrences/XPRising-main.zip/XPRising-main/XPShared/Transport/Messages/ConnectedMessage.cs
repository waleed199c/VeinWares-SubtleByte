﻿namespace XPShared.Transport.Messages;

public class ConnectedMessage : IChatMessage
{
    public void Serialize(BinaryWriter writer)
    {
    }

    public void Deserialize(BinaryReader reader)
    {
    }
}